package org.girish.twonumbersaddition;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText edText1, edText2;
    TextView textResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edText1 = (EditText) findViewById(R.id.editText1);
        edText2 = (EditText) findViewById(R.id.editText2);
        textResult = (TextView) findViewById(R.id.textView);
    }

    public void addNumbers(View view) {
        int n1 = Integer.parseInt(edText1.getText().toString());
        int n2 = Integer.parseInt(edText2.getText().toString());
        int n = n1 + n2;
        textResult.setText(Integer.toString(n));
    }
}
