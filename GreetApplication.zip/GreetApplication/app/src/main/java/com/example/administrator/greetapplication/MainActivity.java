package com.example.administrator.greetapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    EditText edText1;
    TextView textResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edText1 = (EditText)findViewById(R.id.editText);
        textResult = (TextView)findViewById(R.id.textView);

    }

    public void greetMsg(View view) {
        textResult.setText("Good morning " + edText1.getText());
    }

}
