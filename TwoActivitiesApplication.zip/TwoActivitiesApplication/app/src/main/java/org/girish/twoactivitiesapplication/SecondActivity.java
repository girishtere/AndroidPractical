package org.girish.twoactivitiesapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView tv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        tv1 = (TextView) findViewById(R.id.textView3);
        Intent intent = getIntent();
        String s1 = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        tv1.setText("Good morning " + s1);
    }

}
