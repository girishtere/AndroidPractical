package org.girish.twoactivitiesapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    public static final String EXTRA_MESSAGE="org.girish.twoactivitiesapplication.extra.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=(EditText)findViewById(R.id.editText1);
    }

    public void sendMessage(View view) {
        Intent intent = new Intent(this, SecondActivity.class);
        String message=ed1.getText().toString();
        intent.putExtra( EXTRA_MESSAGE, message);
        startActivity(intent);
    }
}
